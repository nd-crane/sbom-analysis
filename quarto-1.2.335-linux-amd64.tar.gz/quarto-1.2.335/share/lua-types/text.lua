---@meta

local text = require 'pandoc.text'

return text